#include "gotocelldialog.h"
#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    // 创建并显示对话框
    GoToCellDialog w;
    w.show();

    return a.exec();
}