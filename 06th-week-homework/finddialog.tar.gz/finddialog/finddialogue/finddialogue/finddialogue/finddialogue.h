// Module
// File: finddialogue.h   Version: 0.1.0   License: AGPLv3
// Created: Chunlin Feng  1356962534@qq.com   2026-04-12 18:33:24
// Description:
// 单继承+值对象
#ifndef FINDDIALOGUE_H
#define FINDDIALOGUE_H

#include <QDialog>
#include "ui_finddialogue.h"   // 值对象需要完整定义

class FindDialogue : public QDialog   // 单继承
{
    Q_OBJECT

public:
    explicit FindDialogue(QWidget *parent = nullptr);
    // 不需要析构函数，ui 会自动销毁

signals:
    void findNext(const QString &str, Qt::CaseSensitivity cs);
    void findPrevious(const QString &str, Qt::CaseSensitivity cs);

private slots:
    void findClicked();
    void enableFindButton(const QString &text);

private:
    Ui::FindDialogue ui;   // 值对象组合
};

#endif // FINDDIALOGUE_H