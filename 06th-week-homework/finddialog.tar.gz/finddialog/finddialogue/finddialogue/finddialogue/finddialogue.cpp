// Module
// File: finddialogue.cpp   Version: 0.1.0   License: AGPLv3
// Created: Chunlin Feng  1356962534@qq.com   2026-04-12 18:33:32
// Description:
// 单继承+值对象
#include "finddialogue.h"

FindDialogue::FindDialogue(QWidget *parent)
    : QDialog(parent)
{
    // 用 . 访问 ui（不是 ->）
    ui.setupUi(this);

    // 连接信号槽
    connect(ui.lineEdit, &QLineEdit::textChanged,
            this, &FindDialogue::enableFindButton);
    connect(ui.findButton, &QPushButton::clicked,
            this, &FindDialogue::findClicked);
    connect(ui.closeButton, &QPushButton::clicked,
            this, &QDialog::close);

    // 初始状态
    ui.findButton->setEnabled(false);

    // 固定高度
    setFixedHeight(sizeHint().height());
}

void FindDialogue::findClicked()
{
    QString text = ui.lineEdit->text();
    Qt::CaseSensitivity cs = ui.caseCheckBox->isChecked()
                                 ? Qt::CaseSensitive
                                 : Qt::CaseInsensitive;

    if (ui.backwardCheckBox->isChecked()) {
        emit findPrevious(text, cs);
    } else {
        emit findNext(text, cs);
    }
}

void FindDialogue::enableFindButton(const QString &text)
{
    ui.findButton->setEnabled(!text.isEmpty());
}