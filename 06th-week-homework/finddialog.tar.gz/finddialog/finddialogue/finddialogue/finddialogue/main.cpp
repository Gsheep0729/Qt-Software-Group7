// Module
// File: main.cpp   Version: 0.1.0   License: AGPLv3
// Created: Chunlin Feng  1356962534@qq.com   2026-04-12 18:33:40
// Description:
// 单继承+值对象
#include <QApplication>
#include "finddialogue.h"

int main(int argc, char *argv[])
{
    QApplication app(argc, argv);
    FindDialogue dialog;
    dialog.show();
    return app.exec();
}