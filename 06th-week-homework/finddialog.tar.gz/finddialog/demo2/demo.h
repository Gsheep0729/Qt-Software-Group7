#pragma once

#include <QMainWindow>

QT_BEGIN_NAMESPACE
namespace Ui {
    class demo;
}
QT_END_NAMESPACE

class demo : public QMainWindow
{
    Q_OBJECT

public:
    explicit demo(QWidget *parent = nullptr);
    ~demo() override;

private:
    Ui::demo *ui;
};
