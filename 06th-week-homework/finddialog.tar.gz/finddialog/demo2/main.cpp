#include <QApplication>
#include "finddialogue.h"

int main(int argc, char *argv[])
{
    QApplication app(argc, argv);
    FindDialogue dialog;
    dialog.show();
    return app.exec();
}