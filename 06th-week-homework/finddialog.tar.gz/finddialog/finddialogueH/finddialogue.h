// Module
// File: finddialogue.h   Version: 0.1.0   License: AGPLv3
// Created: Chunlin Feng  1356962534@qq.com   2026-04-12 18:51:44
// Description:
//
#pragma once

#include <QDialog>

namespace Ui {
    class FindDialogue;
}

class FindDialogue : public QDialog
{
    Q_OBJECT

public:
    explicit FindDialogue(QWidget *parent = nullptr);
    ~FindDialogue();

signals:
    void findNext(const QString &str, Qt::CaseSensitivity cs);
    void findPrevious(const QString &str, Qt::CaseSensitivity cs);

private slots:
    void on_lineEdit_textChanged(const QString &text);  // 自动连接槽
    void on_findButton_clicked();                       // 自动连接槽

private:
    Ui::FindDialogue *_ui;   // 指针成员（不是值对象）
};