#pragma once

#include <QtCore/qglobal.h>

#if defined(FINDDIALOGUEH_LIBRARY)
#define FINDDIALOGUEH_EXPORT Q_DECL_EXPORT
#else
#define FINDDIALOGUEH_EXPORT Q_DECL_IMPORT
#endif
