// Module
// File: finddialogue.cpp   Version: 0.1.0   License: AGPLv3
// Created: Chunlin Feng  1356962534@qq.com   2026-04-12 18:51:56
// Description:
//
#include "finddialogue.h"
#include "ui_finddialogue.h"

FindDialogue::FindDialogue(QWidget *parent)
    : QDialog(parent)
    , _ui(new Ui::FindDialogue)   // new 出来
{
    _ui->setupUi(this);           // 构建界面

    // 如果不用自动连接，手动连接也可以
    // connect(_ui->lineEdit, &QLineEdit::textChanged,
    //         this, &FindDialogue::on_lineEdit_textChanged);
    // connect(_ui->findButton, &QPushButton::clicked,
    //         this, &FindDialogue::on_findButton_clicked);
    // connect(_ui->closeButton, &QPushButton::clicked,
    //         this, &FindDialogue::close);

    _ui->findButton->setEnabled(false);
    setFixedHeight(sizeHint().height());
}

FindDialogue::~FindDialogue()
{
    delete _ui;   // 记得 delete
}

// 槽函数：输入框文字变化
void FindDialogue::on_lineEdit_textChanged(const QString &text)
{
    _ui->findButton->setEnabled(!text.isEmpty());
}

// 槽函数：点击 Find 按钮
void FindDialogue::on_findButton_clicked()
{
    QString text = _ui->lineEdit->text();
    Qt::CaseSensitivity cs = _ui->caseCheckBox->isChecked()
                                 ? Qt::CaseSensitive
                                 : Qt::CaseInsensitive;

    if (_ui->backwardCheckBox->isChecked()) {
        emit findPrevious(text, cs);
    } else {
        emit findNext(text, cs);
    }
}